const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, 'genitive-map-blocks.json'), 'utf8');
const lookup = fs.readFileSync(path.join(__dirname, 'lookup.js'), 'utf8')
  .replace(/^'use strict';\s*/u, '').replace(/module\.exports = \{ createLookup \};\s*$/u, '');
const header = `/*
 * Morphological DATA: OpenCorpora, CC BY-SA 3.0.
 * https://opencorpora.org/?page=faq
 * https://creativecommons.org/licenses/by-sa/3.0/
 * Snapshot via Az.js, revision 394551, compiled 2016-04-14.
 * Source: https://github.com/denull/Az.js/tree/fa73ae7aeb193f830ae0755ffbb055ec1e37d89c/dicts
 * Adaptations: singular genitive nouns/adjectives; personal-name tags excluded;
 * suffix transformations, front-coded blocks, bounded lazy decoding.
 * DATA remains CC BY-SA 3.0. The lookup code is separate application code.
 * Rebuild: az-morphology-research/compile-map.js, compile-blocks.js, build-runtime.js.
 */
`;
const output = header + `(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.DeliveryMorphology = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";
${lookup}
  const data = ${source};
  return Object.freeze({ ...createLookup(data), createLookup, source: Object.freeze(data.source) });
});
`;
fs.writeFileSync(path.join(__dirname, '../delivery_morphology.js'), output);
fs.writeFileSync(path.join(__dirname, '../ru-morphology-data.json'), source);
console.log(JSON.stringify({ runtimeBytes: Buffer.byteLength(output), dataBytes: Buffer.byteLength(source) }));
