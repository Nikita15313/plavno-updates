// Research-only build-time projection of Az's OpenCorpora dictionary.
// Source dictionary license remains CC BY-SA 3.0, not Az code's MIT license.
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const Az = require('./Az.js-master/dist/az');
const root = path.join(__dirname, 'Az.js-master/dicts');
const raw = fs.readFileSync(path.join(root, 'words.dawg'));
const dawg = Az.DAWG.fromArrayBuffer(raw.buffer.slice(raw.byteOffset, raw.byteOffset + raw.byteLength), 'words');
const tags = JSON.parse(fs.readFileSync(path.join(root, 'gramtab-opencorpora-int.json'), 'utf8'));
const suffixes = JSON.parse(fs.readFileSync(path.join(root, 'suffixes.json'), 'utf8'));
const rawParadigms = fs.readFileSync(path.join(root, 'paradigms.array'));
const list = new Uint16Array(rawParadigms.buffer.slice(rawParadigms.byteOffset, rawParadigms.byteOffset + rawParadigms.byteLength));
const paradigms = [];
for (let i = 0, offset = 1; i < list[0]; i++) { const n = list[offset++]; paradigms.push(list.subarray(offset, offset + n)); offset += n; }
const prefixes = ['', 'по', 'наи'];
const nouns = new Map(), adjectives = new Map();
const started = performance.now();
let words = 0, forms = 0;
const token = (tag, value) => new RegExp(`(?:^|[ ,])${value}(?:$|[ ,])`).test(tag);
const tagInfo = tags.map(tag => ({ tag, kind: token(tag, 'NOUN') ? 'n' : token(tag, 'ADJF') ? 'a' : '',
  gent: token(tag, 'gent'), nomn: token(tag, 'nomn'), sing: token(tag, 'sing'),
  person: /(?:^|[ ,])(?:Name|Surn|Patr)(?:$|[ ,])/.test(tag),
  gender: token(tag, 'masc') ? 'm' : token(tag, 'femn') ? 'f' : token(tag, 'neut') ? 'n' : '' }));
const metadata = paradigms.map(p => {
  const count = p.length / 3;
  const targets = { n: {}, a: {} };
  for (let index = 0; index < count; index++) {
    const tag = tagInfo[p[count + index]];
    if (tag.kind && tag.nomn && tag.sing && tag.gender && !tag.person && targets[tag.kind][tag.gender] === undefined) targets[tag.kind][tag.gender] = index;
  }
  return { count, targets };
});
const key = s => s.replace(/ё/g, 'е');
function add(map, spelling, value) { const k = key(spelling); if (!map.has(k)) map.set(k, new Set()); map.get(k).add(value); }
function readWord(word, payloadIndex) {
  words++;
  if (word.length < 4 || word.length > 40) return;
  for (const [paradigmIndex, formIndex] of dawg.iterateAll(payloadIndex)) {
    const p = paradigms[paradigmIndex];
    if (!p) continue;
    const { count, targets } = metadata[paradigmIndex];
    const tag = tagInfo[p[count + formIndex]];
    if (!tag?.kind || !tag.gent || !tag.sing || tag.person || !tag.gender) continue;
    const base = word.slice(prefixes[p[2 * count + formIndex]].length, word.length - suffixes[p[formIndex]].length);
    const inflect = index => prefixes[p[2 * count + index]] + base + suffixes[p[index]];
    if (tag.kind === 'n') {
      const index = targets.n[tag.gender];
      if (index === undefined) continue;
      const normal = inflect(index);
      if (normal !== word) add(nouns, word, `${normal}|${tag.gender}`);
    } else {
      if (['m', 'f', 'n'].some(gender => targets.a[gender] === undefined)) continue;
      add(adjectives, word, ['m', 'f', 'n'].map(gender => inflect(targets.a[gender])).join('|'));
    }
    forms++;
  }
}
function traverse(index, word) {
  for (let code = dawg.guide[index * 2]; code;) {
    const child = dawg.followByte(code, index);
    if (child < 0) throw new Error('Invalid DAWG edge');
    if (code === 1) readWord(word, child);
    else if (word.length < 40 && (code === 45 || code === 184 || code >= 224)) {
      traverse(child, word + (code === 45 ? '-' : code === 184 ? 'ё' : String.fromCharCode(code + 848)));
    }
    code = dawg.guide[child * 2 + 1];
  }
}
traverse(0, '');
const project = map => Object.fromEntries([...map].filter(([, values]) => values.size <= 3)
  .sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0)
  .map(([spelling, values]) => [spelling, [...values].sort()]));
const result = { nouns: project(nouns), adjectives: project(adjectives) };
const encoded = JSON.stringify(result);
fs.writeFileSync(path.join(__dirname, 'genitive-map.json'), encoded);
const report = { elapsedMs: Math.round(performance.now() - started), words, forms,
  nouns: Object.keys(result.nouns).length, adjectives: Object.keys(result.adjectives).length,
  bytes: Buffer.byteLength(encoded), gzipBytes: zlib.gzipSync(encoded).length,
  sha256: crypto.createHash('sha256').update(encoded).digest('hex'),
  examples: Object.fromEntries(['солнца','кольца','порта','моря','треугольника','сияния'].map(word => [word, result.nouns[word]])),
  adjectiveExamples: Object.fromEntries(['белого','красного','большого','балтийского','северного'].map(word => [word, result.adjectives[word]])) };
fs.writeFileSync(path.join(__dirname, 'genitive-map-report.json'), JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
function regularAdjective(word) {
  const ending = word.match(/(?:ого|его|ой|ей)$/u)?.[0];
  if (!ending) return '';
  const stem = word.slice(0, -ending.length);
  const soft = ending === 'его' || ending === 'ей';
  return [stem + (soft || /[гкхжчшщ]$/u.test(stem) ? 'ий' : 'ый'), stem + (soft ? 'яя' : 'ая'), stem + (soft ? 'ее' : 'ое')].join('|');
}
const compactNouns = Object.fromEntries(Object.entries(result.nouns).map(([word, values]) => [word, values.map(value => {
  const [normal, gender] = value.split('|');
  let same = 0;
  while (same < Math.min(word.length, normal.length) && word[same] === normal[same]) same++;
  return `${word.length - same}${normal.slice(same)}${gender}`;
}).join('/') ]));
const irregularAdjectives = Object.fromEntries(Object.entries(result.adjectives).filter(([word, values]) => values.length !== 1 || values[0] !== regularAdjective(word)));
const compact = JSON.stringify({ n: compactNouns, a: irregularAdjectives });
fs.writeFileSync(path.join(__dirname, 'genitive-map-compact.json'), compact);
const compactReport = { nouns: Object.keys(compactNouns).length, irregularAdjectives: Object.keys(irregularAdjectives).length,
  bytes: Buffer.byteLength(compact), gzipBytes: zlib.gzipSync(compact).length,
  sha256: crypto.createHash('sha256').update(compact).digest('hex') };
fs.writeFileSync(path.join(__dirname, 'genitive-map-compact-report.json'), JSON.stringify(compactReport, null, 2));
console.log(JSON.stringify({ compact: compactReport }, null, 2));
