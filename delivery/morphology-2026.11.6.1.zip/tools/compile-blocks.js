const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const source = JSON.parse(fs.readFileSync(path.join(__dirname, 'genitive-map-compact.json'), 'utf8'));
const delta = (from, to) => {
  let same = 0;
  while (same < Math.min(from.length, to.length) && from[same] === to[same]) same++;
  return `${from.length - same}${to.slice(same)}`;
};
function blocks(map, adjective = false) {
  const entries = Object.entries(map);
  const result = [];
  for (let start = 0; start < entries.length; start += 128) {
    let previous = '';
    const records = entries.slice(start, start + 128).map(([word, original]) => {
      let same = 0;
      while (same < Math.min(previous.length, word.length) && previous[same] === word[same]) same++;
      const value = adjective ? original.map(forms => forms.split('|').map(form => delta(word, form)).join('|')).join(';') : original;
      const record = `${same.toString(36)}:${word.slice(same)}\t${value}`;
      previous = word;
      return record;
    });
    result.push([entries[start][0], records.join('\n')]);
  }
  return result;
}
const result = {
  schema: 1, blockSize: 128,
  source: { name: 'OpenCorpora', license: 'CC BY-SA 3.0', url: 'https://opencorpora.org/?page=faq',
    licenseUrl: 'https://creativecommons.org/licenses/by-sa/3.0/', snapshot: '2016-04-14', revision: '394551',
    via: 'https://github.com/denull/Az.js/tree/fa73ae7aeb193f830ae0755ffbb055ec1e37d89c/dicts',
    sourceCommit: 'fa73ae7aeb193f830ae0755ffbb055ec1e37d89c',
    changes: 'Singular genitive noun/adjective forms only; Name/Surn/Patr excluded; suffix transformations and front-coded blocks.' },
  n: blocks(source.n), a: blocks(source.a, true),
};
const text = JSON.stringify(result);
fs.writeFileSync(path.join(__dirname, 'genitive-map-blocks.json'), text);
console.log(JSON.stringify({ bytes: Buffer.byteLength(text), gzipBytes: zlib.gzipSync(text).length,
  nounBlocks: result.n.length, adjectiveBlocks: result.a.length, sha256: crypto.createHash('sha256').update(text).digest('hex') }, null, 2));
