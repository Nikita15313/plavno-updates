'use strict';
function createLookup(data, options = {}) {
  const cache = new Map();
  const maximumBlocks = Math.max(1, Math.min(16, Number(options.cacheBlocks) || 16));
  const key = word => String(word || '').toLocaleLowerCase('ru-RU').replace(/ё/g, 'е');
  function lookup(kind, query) {
    const word = key(query);
    const blocks = data[kind];
    if (!word || !blocks?.length) return '';
    let low = 0, high = blocks.length - 1, selected = -1;
    while (low <= high) {
      const middle = (low + high) >>> 1;
      if (blocks[middle][0] <= word) { selected = middle; low = middle + 1; }
      else high = middle - 1;
    }
    if (selected < 0) return '';
    const cacheKey = `${kind}:${selected}`;
    let decoded = cache.get(cacheKey);
    if (!decoded) {
      decoded = new Map();
      let previous = '';
      for (const line of blocks[selected][1].split('\n')) {
        const colon = line.indexOf(':'), tab = line.indexOf('\t');
        const prefixLength = parseInt(line.slice(0, colon), 36);
        previous = previous.slice(0, prefixLength) + line.slice(colon + 1, tab);
        decoded.set(previous, line.slice(tab + 1));
      }
      if (cache.size >= maximumBlocks) cache.delete(cache.keys().next().value);
    } else cache.delete(cacheKey);
    cache.set(cacheKey, decoded);
    return decoded.get(word) || '';
  }
  function decodeDelta(word, value) {
    const match = value.match(/^(\d+)(.*)$/u);
    return match ? word.slice(0, word.length - Number(match[1])) + match[2] : '';
  }
  function nouns(word) {
    const input = key(word);
    const value = lookup('n', input);
    return value ? value.split('/').map(item => ({ word: decodeDelta(input, item.slice(0, -1)), gender: item.slice(-1) })) : [];
  }
  function adjectives(word, gender) {
    const input = key(word);
    const genderIndex = ['m', 'f', 'n'].indexOf(gender);
    if (genderIndex < 0) return [];
    const irregular = lookup('a', input);
    if (irregular) return irregular.split(';').map(forms => decodeDelta(input, forms.split('|')[genderIndex]));
    const ending = input.match(/(?:ого|его|ой|ей)$/u)?.[0];
    if (!ending) return [];
    const stem = input.slice(0, -ending.length), soft = ending === 'его' || ending === 'ей';
    return [stem + [soft || /[гкхжчшщ]$/u.test(stem) ? 'ий' : 'ый', soft ? 'яя' : 'ая', soft ? 'ее' : 'ое'][genderIndex]];
  }
  function preserveCase(original, replacement) {
    if (original === original.toLocaleUpperCase('ru-RU')) return replacement.toLocaleUpperCase('ru-RU');
    return /^[А-ЯЁ]/u.test(original) ? replacement.charAt(0).toLocaleUpperCase('ru-RU') + replacement.slice(1) : replacement;
  }
  function phraseVariants(name) {
    const words = String(name || '').trim().split(/\s+/u);
    if (words.length < 2 || words.length > 6 || words.some(word => !/^[а-яё-]+$/iu.test(word))
      || !/(?:ого|его|ой|ей)$/iu.test(words[0])) return [];
    const choices = nouns(words[words.length - 1]);
    const results = [];
    for (const noun of choices) {
      const prefixes = words.slice(0, -1).map(word => adjectives(word, noun.gender));
      if (prefixes.some(values => !values.length)) continue;
      const result = [...prefixes.map((values, index) => preserveCase(words[index], values[0])), preserveCase(words[words.length - 1], noun.word)].join(' ');
      if (result !== name && !results.includes(result)) results.push(result);
      if (results.length >= 2) break;
    }
    return results;
  }
  return { nouns, adjectives, phraseVariants, cacheSize: () => cache.size };
}
module.exports = { createLookup };
