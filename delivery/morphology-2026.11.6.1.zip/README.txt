COMPACT RUSSIAN MORPHOLOGY — DELIVERY CALCULATOR 2026.11.6.1

Files
  ru-morphology-data.json  Adapted CC BY-SA 3.0 data and source metadata.
  tools/lookup.js         Bounded lazy lookup and phrase-variant source.
  tools/compile-map.js    Build-time projection of the source DAWG dictionary.
  tools/compile-blocks.js Front-coded data generation.
  tools/build-runtime.js  Generation of the self-contained browser/Node module.
  NOTICE.txt             Attribution, source revision and adaptation details.
  LICENSE-Az.txt         MIT license for the upstream build-time Az.js library.

To reproduce
1. Obtain the pinned upstream source:
   https://github.com/denull/Az.js/archive/fa73ae7aeb193f830ae0755ffbb055ec1e37d89c.zip
2. Extract it as tools/Az.js-master (that folder must contain dist/ and dicts/).
3. With Node.js installed, run from this archive's extracted root:
   node tools/compile-map.js
   node tools/compile-blocks.js
   node tools/build-runtime.js
4. The root then contains delivery_morphology.js and ru-morphology-data.json.

The production application needs none of those build steps. It embeds the
generated data and lookup module. The full dictionary is used only to rebuild.

Data format
  schema: 1; blockSize: 128.
  n: noun blocks; a: irregular adjective blocks.
  Each block has its first full key and newline-separated records.
  A record starts with a base-36 shared-prefix length, colon, key suffix, tab,
  and encoded value. Noun values encode removed-suffix length, added suffix,
  and gender (m/f/n). Slash separates noun alternatives. Adjective values use
  pipe-separated masculine/feminine/neuter suffix deltas; semicolon separates
  alternatives. lookup.js is the reference decoder.

The data is licensed separately from independent application code; see NOTICE.
